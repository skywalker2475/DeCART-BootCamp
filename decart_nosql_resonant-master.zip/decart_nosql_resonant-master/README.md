# NoSQL
Preparation for the Resonant Course
